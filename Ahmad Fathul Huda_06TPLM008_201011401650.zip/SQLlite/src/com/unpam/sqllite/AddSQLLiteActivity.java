package com.unpam.sqllite;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.widget.EditText;
import android.widget.Toast;
import com.unpam.sqllite.DataHelper;

public class AddSQLLiteActivity extends Activity {
	DataHelper dh; 
	EditText judul, isi; 
	int id=0;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sqllite);
        
        judul = (EditText) findViewById(R.id.judulEditText); 
        isi = (EditText) findViewById(R.id.isiEditText); 
        
        dh = new DataHelper(this);
        if (getIntent().getExtras() != null) {
        	id = getIntent().getIntExtra("_id", 0);
        	Cursor c = dh.getById(id);
        	if (c.moveToFirst()) { // pasti hanya satu karena id unik
        		do {
        		}  while (c.moveToNext());
        		
        	}
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_add_sqllite, menu);
        return true;
    }
    
    
    @Override
    protected void onPause() {
    	if (!judul.getText().toString().equals("")) {
    		if (id > 0) {
    			// TODO update ke db
    		} else { 
    			id = (int) dh.insert2(judul.getText().toString(),isi.getText().toString()); 
    			Toast.makeText(this,"Disimpan: " + Integer.toString(id) + ": " + judul.getText(),
    			Toast.LENGTH_SHORT).show();
    	}
    	
    }
    	super.onPause();
}
}
